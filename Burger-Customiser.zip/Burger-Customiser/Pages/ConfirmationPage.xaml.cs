﻿using System.Windows.Controls;
using System.Windows.Input;

namespace Burger_Customiser.Pages {

    /// <summary>
    /// Interaction logic for ConfirmationPage.xaml
    /// </summary>
    public partial class ConfirmationPage : Page {

        public ConfirmationPage() {
            InitializeComponent();
        }

        private void IdleScreenLMBDown(object sender, MouseButtonEventArgs e) {
        }
    }
}