﻿using System.Windows.Controls;

namespace Burger_Customiser.Pages {

    /// <summary>
    /// Interaction logic for ShoppingCartPage.xaml
    /// </summary>
    public partial class ShoppingCartPage : Page {

        public ShoppingCartPage() {
            InitializeComponent();
        }
    }
}