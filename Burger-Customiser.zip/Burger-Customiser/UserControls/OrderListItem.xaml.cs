﻿using System.Windows.Controls;

namespace Burger_Customiser.UserControls {

    /// <summary>
    /// Interaction logic for OrderListItem.xaml
    /// </summary>
    public partial class OrderListItem : UserControl {

        public OrderListItem() {
            InitializeComponent();
        }
    }
}